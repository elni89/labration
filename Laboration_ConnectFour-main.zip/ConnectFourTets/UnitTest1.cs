using Xunit;
using ConnectFour;

namespace ConnectFour.Tests
{
    public class GameStateTests
    {
        [Fact]
        public void CheckForWin_NoWinner_EmptyBoard()
        {
            var gameState = new GameState();

            var result = gameState.CheckForWin();

            Assert.Equal(GameState.WinState.No_Winner, result);
        }

        [Fact]
        public void CheckForWin_TieGame()
        {
            var gameState = new GameState();

            for (int i = 0; i < 42; i++)
            {
                gameState.TheBoard[i] = 3;
            }

            var result = gameState.CheckForWin();

            Assert.Equal(GameState.WinState.Tie, result);
        }
    }
}
